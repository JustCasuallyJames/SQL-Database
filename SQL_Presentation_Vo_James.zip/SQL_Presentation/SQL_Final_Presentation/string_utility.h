#pragma once
#include <iostream>

using namespace std;

string uppercase(string word);
string lowercase(string word);